# Group Identification

 - Eduardo Espadeiro, 95568, eduardo.espadeiro@tecnico.ulisboa.pt
 - Guilherme Salvador, 95584, guilherme.salvador@tecnico.ulisboa.pt
 - João Matos, 95610, joao.rui.matos@tecnico.ulisboa.pt 

# Implemented Features
We completed all the all the exercises of the assignment.
We implemented all the features in collaboration, meaning that we did not have split the work in a way that each one of us did a specific feature

# Extras
We did not implement any extra features.